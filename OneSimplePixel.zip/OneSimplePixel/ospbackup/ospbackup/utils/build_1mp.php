<?php

echo "<html><body><center><h1>BUILDING IMAGE...</h1></center>";

//Open Image and Create Merge
$im = imagecreate(1000, 1000);
$bgcolor = imagecolorallocate($im, 0xFF, 0xFF, 0xFF);
imagefill($im , 0,0 , $bgcolor);


//Connect to DB
if (!$db = mysql_connect("localhost", "onesi3_admin", "humbl3")) {
   echo 'Could not connect to mysql';
   exit;
}

if (!mysql_select_db('onesi3_1mp', $db)) {
   echo 'Could not select database';
   exit;
}

$sql    = 'SELECT * FROM 1mp';
$result = mysql_query($sql, $db);

if (!$result) {
   echo "DB Error, could not query the database\n";
   echo 'MySQL Error: ' . mysql_error();
   exit;
}

//build palette
$colors = array(0,51,102,153,204,255);

for($i=0; $i< 6; $i++)
{
	for($j=0; $j< 6; $j++)
	{
		for($k=0; $k< 6; $k++)
		{
			imagecolorallocate($im, $colors[$i], $colors[$j], $colors[$k]);
		}
	}
}


$c = imagecolorallocate($im, 0x00, 0x00, 0x00);
imagecolordeallocate($im, $c);

printf("<br>building image<br>");
while ($row = mysql_fetch_assoc($result)) {

	$c = imagecolorexact($im, hexdec(substr($row["pixelColor"], 0,2)), hexdec(substr($row["pixelColor"], 2,2)), hexdec(substr($row["pixelColor"], 4,2)));
	imagesetpixel($im, $row["x"], $row["y"], $c);
}

mysql_free_result($result);
mysql_close($db);

imageGIF($im,"../images/1mp_rebuilt.gif", 100);
imagedestroy($im);
echo "<br><a href=../images/1mp_rebuilt.gif method=post>image rebuilt</a>";
echo "</body></html>";
?>