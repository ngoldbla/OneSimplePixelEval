<?php

//GLOBALS
$MAIN_SCRIPT = "./index.php";


function documentStyle()
{
	$text = "<style type=\"text/css\">

				label.smallinput
				{
					font: 10px arial,serif;
					color: black;
				}
				input.smallinput
				{
					font: 10px arial,serif;
					border: 1px solid #D4D4D4;
					background: #FFFFFF;
				}

				input.buttonsmallinput
				{
					font: 10px arial,serif;
					border: 1px solid #D4D4D4;
				}

				textarea.smallinput
				{
					font: 10px arial,serif;
					border: 1px solid #D4D4D4;
					background: #FFFFFF;
				}

				select.smallinput
				{
					font: 10px arial,serif;
					border-width: 1px;
					border-color: #D4D4D4;
					background: #FFFFFF;
				}

				img.border
				{
					border-width: 1px;
					border-color: #D4D4D4;
				}

				table.border
				{
					border-width: 1px;
					border-color: #D4D4D4;
				}
			</style>";

	return $text;
}

function documentScripts()
{
	$text = "<script type=\"text/javascript\" src=\"zoom.js\"></script>
			 <script type=\"text/javascript\" src=\"validate.js\"></script>
			 <script type=\"text/javascript\" src=\"picker.js\"></script>

			 <script type=\"text/javascript\">
			 function checkWholeForm() {
				var why = \"\";
				why += checkEmail(document.pixelinfo.humanemail.value);
				if (!document.pixelinfo.verified.checked) why +=\"Please review and accept the terms before adding a pixel.\"
				if (why != \"\") {
				   alert(why);
				   return false;
				}
			 return true;
			 }
			 </script>";


	return $text;
}

function htmlHeader()
{
	$text = "<html>
			 <head>
			 <title>onesimplepixel - one million pixels project</title>" .
			 documentStyle() .
			 documentScripts() .
			 "</head>";

	return $text;
}


function htmlFooter()
{
	$text = "</html>";

	return $text;
}

function adRight()
{
	$text = "
			<!-- Begin: AdBrite -->
			<script type=\"text/javascript\">
			   var AdBrite_Title_Color = '0000FF';
			   var AdBrite_Text_Color = '000000';
			   var AdBrite_Background_Color = 'FFFFFF';
			   var AdBrite_Border_Color = 'D4D4D4';
			</script>
			<script src=\"http://ads.adbrite.com/mb/text_group.php?sid=210142&zs=3132305f363030\" type=\"text/javascript\"></script>
			<div><a target=\"_top\" href=\"http://www.adbrite.com/mb/commerce/purchase_form.php?opid=210142&afsid=1\" style=\"font-weight:bold;font-family:Arial;font-size:13px;\">Your Ad Here</a></div>
			<!-- End: AdBrite -->";


	$text2 = "<script type=\"text/javascript\"><!--
			google_ad_client = \"pub-0389366370219462\";
			google_ad_width = 120;
			google_ad_height = 600;
			google_ad_format = \"120x600_as\";
			google_ad_type = \"text\";
			google_ad_channel = \"\";
			google_color_border = \"D4D4D4\";
			google_color_bg = \"FFFFFF\";
			google_color_link = \"0000FF\";
			google_color_text = \"000000\";
			google_color_url = \"008000\";
			//--></script>
			<script type=\"text/javascript\"
			  src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">
			</script>";

	return $text;

}


function bodyHeader()
{
	$text = "<body bgcolor=\"#FFFFFF\">
			<form name=\"pixelinfo\" action=\"$MAIN_SCRIPT\" method=post onSubmit=\"return checkWholeForm()\">
			<table border=\"0\" width=\"1000px\" cellpadding=\"0%\" cellspacing=\"0%\" align=\"center\">
				<tr>
    				<td colspan=\"2\">
<script type=\"text/javascript\"><!--
google_ad_client = \"pub-0389366370219462\";
google_ad_width = 728;
google_ad_height = 90;
google_ad_format = \"728x90_as\";
google_ad_type = \"text_image\";
google_ad_channel = \"\";
google_color_border = \"D4D4D4\";
google_color_bg = \"FFFFFF\";
google_color_link = \"0000FF\";
google_color_text = \"000000\";
google_color_url = \"008000\";
//--></script>
<script type=\"text/javascript\"
  src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">
</script>
    				<br><a href=\"http://www.onesimplepixel.com\"><img border=\"0\" src=\"./images/onemillionpixelslogo.jpg\"></a><a href=\"./news.html\"><img border=\"0\"  src=\"./images/news.jpg\"></a><a href=\"./about.html\"><img border=\"0\" src=\"./images/about.jpg\"></a><a href=\"http://www.cafepress.com/onesimplepixel\"><img border=\"0\" src=\"./images/stuff.jpg\"></a><img border=\"0\" src=\"./images/header_end.jpg\"></td><td rowspan=\"3\" valign=\"top\" align=\"right\" nowrap> &nbsp;" . adRight() . "</td>
     			</tr>
    			<tr>
    				<td valign=\"top\" align=\"left\" width=\"100%\">
    					<table border=\"0\">";

	return $text;
}

function bodyFooter()
{
	$text = "</body>";

	return $text;
}

function googleAnalytics()
{

	$text = "<script src=\"http://www.google-analytics.com/urchin.js\" type=\"text/javascript\"></script><script type=\"text/javascript\">_uacct = \"UA-943683-3\";urchinTracker();</script>";

	return $text;

}



function bodyNoPixel($x, $y)
{
	$text = "</table>
		  	<table width=\"100%\" border=\"0\">
		  	<tr><td align=\"left\" valign=\"center\" width=\"100%\"><label class=\"smallinput\"><b>pixel's name:</b> </label><input class=\"smallinput\" type=\"text\" name=\"pixelname\"> &nbsp;&nbsp; <label class=\"smallinput\"><b>x:</b> </label><input class=\"smallinput\" type=\"text\" maxlength=\"4\" size=\"3\" name=\"pixelx\" value=\"$x\" readonly>  <label class=\"smallinput\"><b>y:</b> </label><input class=\"smallinput\" type=\"text\" maxlength=\"4\" size=\"3\" name=\"pixely\" value=\"$y\" readonly> &nbsp;&nbsp; <label class=\"smallinput\"><b>color:</b> </label><input class=\"smallinput\" type=\"text\" id=\"pixelcolor\" maxlength=\"7\" size=\"6\" value=\"#000000\" name=\"pixelcolor\" readonly><a href=\"javascript:TCP.popup(document.forms['pixelinfo'].elements['pixelcolor'])\"><img width=\"15\" height=\"13\" border=\"0\" alt=\"Click here to pick a color\" src=\"./images/sel.gif\"></a> &nbsp;&nbsp; <label class=\"smallinput\"><b>country:</b> </label><script type=\"text/javascript\" src=\"country.js\"></script> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type=\"checkbox\" name=\"verified\" value=\"1\"><label class=\"smallinput\"><b>I accept the <a href=\"./terms.html\" target=\"_blank\">terms</a></b></label> <br>
		  	<label class=\"smallinput\"><b>email:</b> </label><input class=\"smallinput\" type=\"text\" id=\"humanemail\" name=\"humanemail\" size=\"45\"> &nbsp;<input type=\"checkbox\" name=\"emailupdate\" checked value=\"1\"><label class=\"smallinput\"><b>email updates</b></label> &nbsp;&nbsp <label class=\"smallinput\"><b>comment/quote:</b> </label><textarea class=\"smallinput\" rows=\"1\" cols=\"80\" name=\"humantext\"></textarea> &nbsp;&nbsp <input class=\"buttonsmallinput\" type=\"submit\" value=\"add pixel\"></td></tr>
		  	</table>
		  	</td>
		  	</tr>";

	return $text;
}


function bodyNoCoords()
{
	//Connect to DB
	if (!$db = mysql_connect("localhost", "onesi3_1mpbeta", "m!ll!0n")) {echo 'Could not connect to mysql'; exit;}
	if (!mysql_select_db('onesi3_1mpbeta', $db)) { echo 'Could not select database'; exit;}

	//Check to see if pixel already exists
	$sql2 = "SELECT count(*) FROM 1mp_beta;";
	$result2 = mysql_query($sql2, $db);

	if( mysql_num_rows ($result2) != 0 )
	{
		$row_count = mysql_fetch_array($result2);
	}

	$text = "<tr><td align=\"left\" valign=\"center\" colspan=\"1\"><label class=\"smallinput\">
<b>welcome to the one million pixels project.  this project is an experiment to create a one million pixels image through the collaboration of one million people one pixel at a time.<br>
join the project today and contribute your one pixel.</b> the current number of pixels is <font color=\"#0000FF\">$row_count[0]</font>.
<br><br>
<b>start by selecting any pixel in the box below.  if the pixel has not been claimed, give it a name, pick a color and share a comment/quote with the world.<br></b>
note: there are one million pixels (1000x1000), so you might need to scroll the webpage to see the entire image.

</label></td><td colspan=\"2\"></td></tr>
			  </table>
			</td>
		    </tr>";

	return $text;
}


function bodyImage()
{
	$text = "<tr>
				<td colspan=2>
					<a href=\"./index.php\" name=\"1mplink\"><img class=\"border\" name=\"myimage\" src=\"./images/1mp.gif\" border=\"1\" ismap></a>
				</td>
			</tr>
			<tr><td colspan=\"2\" valign=\"bottom\">
			<a href=\"http://www.onesimpleidea.com\"><img border=\"0\" src=\"./images/footer.jpg\"></a>
					" . googleAnalytics() . "
    				</td>
     			</tr>
			</table>
		</form>";

	return $text;
}


function redirectHome()
{
	$text = "<html>
			<head>
			<title>onesimplepixel - one million pixels project</title>" . documentStyle() . "
			<meta http-equiv=\"refresh\" content=\"1;url=./index.php\"
			</head>
			<body bgcolor=\"#FFFFFF\"></body></html>";

	return $text;
}


//////////////////////////////////////////////////////////////////
//ADD PIXEL IF A NEW ONE IS SUBMITTED

if (count($_POST))
{
	//Connect to DB
	if (!$db = mysql_connect("localhost", "onesi3_1mpbeta", "m!ll!0n")) {echo 'Could not connect to mysql'; exit;}
	if (!mysql_select_db('onesi3_1mpbeta', $db)) { echo 'Could not select database'; exit;}

	//Check to see if pixel already exists
	$sql = "SELECT * FROM 1mp_beta WHERE (1mp_beta.x =" . $_POST['pixelx'] . ") AND (1mp_beta.y = " . $_POST['pixely'] . ");";
	$result = mysql_query($sql, $db);

	if (!$result) {
	   echo "DB Error, could not query the database\n";
	   echo 'MySQL Error: ' . mysql_error();
	   exit;
	}

	if( mysql_num_rows ($result) == 0 )
	{

		mysql_free_result($result);

		//Check to see if pixel already exists
		$sql = "SELECT * FROM 1mp_beta WHERE (1mp_beta.humanEmail =\"" . $_POST['humanemail'] . "\");";
		$result = mysql_query($sql, $db);

		if (!$result) {
		   echo "DB Error, could not query the database\n";
		   echo 'MySQL Error: ' . mysql_error();
		   exit;
		}


		if( mysql_num_rows ($result) != 0 )
		{
			mysql_free_result($result);


			$text = "<html>
					<head>
					<title>onesimplepixel - one million pixels project</title>" . documentStyle() . "
					<meta http-equiv=\"refresh\" content=\"2;url=./index.php\"
					</head>
					<body bgcolor=\"#FFFFFF\"><form><label class=\"smallinput\">sorry, pixel not added. " . $_POST['humanemail'] . " has already been used.</label></form></body></html>";

			echo $text;
		}
		else
		{
			mysql_free_result($result);

			if ( $_POST['emailupdate']  == "1" ) $emailupdate = TRUE; else $emailupdate = FALSE;
			if ( $_POST['verified']  == "1" ) $verified = TRUE; else $verified = FALSE;

			//If pixel does not exist, place into DB
			$sql = "INSERT INTO `1mp_beta` (`x`, `y`, `count`, `pixelName`, `pixelColor`, `pixelDescription`, `humanEmail`, `update`, `verified`, `humanCountry`, `humanIP`, `DateTime`)
							   VALUES ('" . $_POST['pixelx'] . "',
									   '" . $_POST['pixely'] . "',
									   '',
									   '" . $_POST['pixelname'] . "',
									   '" . substr($_POST['pixelcolor'], 1,6) . "',
									   '" . $_POST['humantext'] . "',
									   '" . $_POST['humanemail'] . "',
									   '" . $emailupdate . "',
									   '" . $verified . "',
									   '" . $_POST['humancountry'] . "',
									   '" . $_SERVER["REMOTE_ADDR"]. "',
									   '" .  date("Y-m-d G:i:s") . "');";
			$result = mysql_query($sql, $db);

			//Update image
			$im = imagecreatefromgif("./images/1mp.gif");

			//build palette
			$colors = array(0,51,102,153,204,255);

			for($i=0; $i< 6; $i++)
			{
				for($j=0; $j< 6; $j++)
				{
					for($k=0; $k< 6; $k++)
					{
						imagecolorallocate($im, $colors[$i], $colors[$j], $colors[$k]);
					}
				}
			}

			$c = imagecolorexact($im, hexdec(substr($_POST['pixelcolor'], 1,2)), hexdec(substr($_POST['pixelcolor'], 3,2)), hexdec(substr($_POST['pixelcolor'], 5,2)));
			imagesetpixel($im, $_POST['pixelx'], $_POST['pixely'], $c);
			imageGIF($im,"./images/1mp.gif");
			imagedestroy($im);


			//Email to verify recipient
			$to      = $_POST['humanemail'];
			$subject = 'one million pixel project';
			$message =
"Thanks for participating in the one million pixel project.  This email is to verify that you recently added a pixel to the image.  The details of the addition are as follows:

	email: " . $_POST['humanemail'] . "
	pixel�s name: " . $_POST['pixelname'] . "
	x: " . $_POST['pixelx'] . "
	y: " . $_POST['pixely'] . "
	color: " . $_POST['pixelcolor'] . "
	country: " . $_POST['humancountry'] . "
	comment/quote: " . $_POST['humantext'] . "

Stay updated on the progress of the project and new additions to the project and onesimplepixel by visiting http://www.onesimplepixel.com.  Thanks again and please continue your support by telling others.  Together one million people can focus one million minds to create one enlightening image.

NOTE: If you opted out of receiving updates on this project and other projects related to www.onesimplepixel.com, you will not received any future emails.  If you did not add this pixel, please reply stating so or visit http://www.onesimplepixel.com/contact.html to report the error.

http://www.onesimpleidea.com
copyright � 2007 onesimple � all rights reserved";
			$headers = 'From: pixel@onesimplepixel.com' . "\r\n" .
			   'Reply-To: pixel@onesimplepixel.com' . "\r\n" .
			   'X-Mailer: PHP/' . phpversion();

			mail($to, $subject, $message, $headers);

			$text = "<html>
					<head>
					<title>onesimplepixel - one million pixels project</title>" . documentStyle() . "
					<meta http-equiv=\"refresh\" content=\"1;url=$MAIN_SCRIPT?" . $_POST['pixelx'] . "," . $_POST['pixely'] . "\"
					</head>
					<body bgcolor=\"#FFFFFF\"><form><label class=\"smallinput\">success! one more pixel added." . $result_count . "</label></form></body></html>";

			echo $text;
		}
	}
	else
	{
		mysql_free_result($result);


		$text = "<html>
				<head>
				<title>onesimplepixel - one million pixels project</title>" . documentStyle() . "
				<meta http-equiv=\"refresh\" content=\"2;url=$MAIN_SCRIPT?" . $_POST['pixelx'] . "," . $_POST['pixely'] . "\"
				</head>
				<body bgcolor=\"#FFFFFF\"><form><label class=\"smallinput\">sorry, pixel not added.  someone just beat you to this pixel.  try again...</label></form></body></html>";

		echo $text;
	}
}
else
{
	//////////////////////////////////////////////////////////////////
	//DOCUMENT OUTPUT

	if (count($_GET))
	{
		$click = array_keys($_GET);
		$click = explode(',', $click[0]);


		/////////////////////
		//Verify Script Input

		//Incorrect Input
		if( count($click)  != 2 )
		{
			echo redirectHome();
		}
		//Correct Input
		else
		{
			echo htmlHeader();
			echo bodyHeader();

			$_SESSION['points'][] = $click[0];
			$_SESSION['points'][] = $click[1];


			if ( $click[0] > 999 )  $click[0] = 999;
			if ( $click[0] < 0 )  $click[0] = 0;
			if ( $click[1] > 999 )  $click[1] = 999;
			if ( $click[1] < 0 )  $click[1] = 0;

			$_GET = $click[0] . "," . $click[1];


			//Connect to DB
			if (!$db = mysql_connect("localhost", "onesi3_1mpbeta", "m!ll!0n"))
			{
			   echo 'Could not connect to mysql';
			   exit;
			}

			if (!mysql_select_db('onesi3_1mpbeta', $db))
			{
			   echo 'Could not select database';
			   exit;
			}


			//Check to see if pixel already exists
			$sql = "SELECT * FROM 1mp_beta WHERE (1mp_beta.x =" . $click[0] . ") AND (1mp_beta.y = " . $click[1] . ");";
			$result = mysql_query($sql, $db);

			if (!$result)
			{
			   echo "DB Error, could not query the database\n";
			   echo 'MySQL Error: ' . mysql_error();
			   exit;
			}


			//Pixel Found
			if( mysql_num_rows ($result) != 0 )
			{
				$row = mysql_fetch_array($result);

				//Output HTML based on pixel existing and include details from record
				echo "</table>
					  <table width=\"100%\" border=\"0\">
					  <tr><td align=\"left\" valign=\"center\" width=\"100%\"><label class=\"smallinput\"><b>pixel's name:</b>$row[pixelName] &nbsp;&nbsp; <b>x:</b>$row[x]  <b>y:</b>$row[y] &nbsp;&nbsp; <b>color:</b> <font color=\"#$row[pixelColor]\">#$row[pixelColor]</font> &nbsp;&nbsp; <b>country:</b> $row[humanCountry]<br><b>comment/quote:</b> $row[pixelDescription] </label></td></tr>
					  </table>
					</td>
				</tr>";

				mysql_free_result($result);
				mysql_close($db);
			}
			else //Pixel not found
			{

				echo bodyNoPixel($click[0], $click[1]);

			}

			echo bodyImage();
			echo bodyFooter();
			echo htmlFooter();
		}
	}
	else //No coordinates passed
	{
		echo htmlHeader();
		echo bodyHeader();
		echo bodyNoCoords();
		echo bodyImage();
		echo bodyFooter();
		echo htmlFooter();

	}
}
?>

